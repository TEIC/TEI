package com.thaiopensource.datatype.xsd;

class IdDatatype extends NCNameDatatype {
  public int getIdType() {
    return ID_TYPE_ID;
  }
}
