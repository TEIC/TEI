package com.thaiopensource.relaxng.output.xsd.basic;

import com.thaiopensource.relaxng.edit.SourceLocation;

import java.util.List;

public class AbstractSchemaVisitor implements SchemaVisitor {
  public void visitGroup(GroupDefinition def) {
  }

  public void visitAttributeGroup(AttributeGroupDefinition def) {
  }

  public void visitSimpleType(SimpleTypeDefinition def) {
  }

  public void visitInclude(Include include) {
  }

  public void visitRoot(RootDeclaration decl) {
  }

  public void visitComment(Comment comment) {
  }
}
