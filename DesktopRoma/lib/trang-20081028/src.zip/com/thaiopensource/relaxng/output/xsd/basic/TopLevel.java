package com.thaiopensource.relaxng.output.xsd.basic;

public interface TopLevel {
  void accept(SchemaVisitor visitor);
}
