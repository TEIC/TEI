package com.thaiopensource.util;

public class VoidValue {
  public static VoidValue VOID = new VoidValue();
  private VoidValue() { }
}
