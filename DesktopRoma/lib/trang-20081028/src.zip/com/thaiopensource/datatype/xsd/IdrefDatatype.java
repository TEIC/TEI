package com.thaiopensource.datatype.xsd;

class IdrefDatatype extends NCNameDatatype {
  public int getIdType() {
    return ID_TYPE_IDREF;
  }
}
