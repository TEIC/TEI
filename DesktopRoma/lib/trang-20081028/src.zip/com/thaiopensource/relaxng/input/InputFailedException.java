package com.thaiopensource.relaxng.input;

public class InputFailedException extends Exception {
}
