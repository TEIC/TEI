package com.thaiopensource.relaxng.output.xsd;

public interface SourceUriGenerator {
  String generateSourceUri(String ns);
}
